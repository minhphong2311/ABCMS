---
name: figma_to_html
description: Kích hoạt khi cần tự động sinh mã HTML/CSS từ thiết kế Figma, phân tích ảnh, trích xuất dữ liệu, hoặc sửa lỗi giao diện qua hệ thống AI Feedback.
---
# Figma to HTML Automation & AI Feedback Engine

## Import Menu from Image
- Uses Gemini 3.5 Flash to extract hierarchical menus.
- Instructs AI to use sequential integers (1, 2, 3...) for IDs and parent_ids to strictly maintain the hierarchy, instead of long UUIDs which AI often forgets or mismatches.
- Python code replaces these integer IDs with actual UUIDs post-processing.
- Requires `from google import genai` and `genai.Client(api_key=...)` (New SDK).

## Quy trình Biên dịch (Dynamic Compilation)
- Sinh mã nguồn HTML/CSS/JS theo cấu trúc `output/<site_id>/<folder>/<slug>.<ext>`.
- Quá trình tạo phải được thực hiện bất đồng bộ (AJAX) và hiển thị trạng thái chờ build ("Analyzing...", "Generating...").
- Nếu Trang chưa được cấu hình Link Figma, nút "Generate" phải ở trạng thái disabled.
- Hệ thống luôn thực hiện biên dịch động trực tiếp từ cấu trúc thiết kế Figma:
  - Trích xuất dữ liệu JSON của Node ID từ Figma API và tải xuống bản đồ hình ảnh (Image Fills Mapping) bằng Personal Access Token (lưu bảo mật chung tại file `data/config.json`) để giải quyết toàn bộ các ảnh và màu nền gradient thực tế.
  - Chạy bộ dịch `compile_figma_node_to_html_css` hỗ trợ đầy đủ các thuộc tính Layout Sizing phức tạp của Figma (`HUG`, `FILL`, `FIXED`, `STRETCH`) để biên dịch trực tiếp ra mã nguồn HTML/CSS tĩnh tự động co giãn tương ứng.
  - Hoàn toàn KHÔNG sử dụng các mẫu giao diện ngoại tuyến được viết sẵn (Offline Fallback Templates).
  - Hỗ trợ lưu cache cấu trúc thiết kế trong tệp tin `data/figma_cache.json` để phục vụ biên dịch ngoại tuyến tức thời nếu Token bị trống hoặc lỗi kết nối.

## Vòng lặp Phản chiếu Thị giác Gemini (Visual Reflection Loop - 100% Figma Match)
- Tự động chụp ảnh màn hình giao diện sinh ra bằng Playwright và gửi kèm ảnh thiết kế Figma cho Gemini Vision (`gemini-3.6-flash` với cơ chế retry tự động). 
- AI kiểm tra và sửa lỗi trực tiếp theo **Checklist 7 bước** (`assets/ai_prompts/quality-checklist.md`):
  1. Layout (bố cục, kích thước, vị trí, căn lề, màu sắc).
  2. Typography (font-family, font-size, font-weight, line-height, letter-spacing, màu chữ, khoảng cách đoạn).
  3. HTML & Class (thẻ HTML chuẩn, Typography Class và HTML Template `.con-box → h4`, `.con-box02 → h5`, `.con-box03 → h6`).
  4. Hình ảnh (export đầy đủ, định dạng .jpg/.png, kích thước, đường dẫn).
  5. Responsive (Desktop, Tablet, Mobile, không vỡ layout).
  6. Chức năng (link, button, hover).
  7. So sánh 100% với Figma: Chỉnh sửa lại HTML/CSS cho tới khi khớp hoàn toàn thiết kế.

## Split-Screen Preview & AI Feedback Engine
- Giao diện xem Preview kết hợp với Phản hồi Thiết kế:
  - Khi bấm Preview, trang quản trị hiển thị giao diện chia đôi tích hợp thanh top navbar quản trị chung. Nút Preview chuyển hướng trực tiếp trên tab hiện tại.
  - Bên trái hiển thị Iframe của trang giao diện thực tế (raw HTML) max-width 1920px.
  - Bên phải hiển thị một Chatbox giao tiếp với Design Critic Agent.
  - Chatbox hiển thị tin nhắn dạng **plain text** (tự động escape HTML entities). Lịch sử lưu vào `localStorage`.
- Bộ máy điều chỉnh HTML/CSS động:
  - Tích hợp **Google Gemini AI** (model: `gemini-3.1-flash-lite`, thư viện: `google-genai`).
  - Backend đọc nội dung **HTML và CSS** hiện tại, gửi kèm yêu cầu. AI cũng được truyền vào nội dung của các template chuẩn từ thư mục `assets/ai_prompts/` và danh sách các thư viện CSS chuẩn của Site.
  - AI trả về toàn bộ HTML và CSS đã được cập nhật dưới dạng JSON. Backend ghi đè trực tiếp vào file tương ứng, Iframe Preview tự động reload.
