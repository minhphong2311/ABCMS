# General Project Rules (ABCMS)

1. Giao diện quản trị được tạo bằng AdminLTE.
2. Phát triển bằng Python Flask.
3. Không sử dụng Database, lưu dữ liệu bằng file JSON.
4. Thống nhất thư mục chứa file tạm thời (Test/Dump/Debug):
   - Tất cả các script dùng để kiểm tra DOM, dump giao diện, debug CMS hoặc các đoạn mã chạy thử (test) chỉ mang tính chất tạm thời **BẮT BUỘC** phải được tạo bên trong thư mục `scratch/`.
   - Thư mục `scripts/` chỉ dành riêng cho các đoạn mã tiện ích phụ trợ (ví dụ: `upload_img_demo.py`). Không được lưu file test vào thư mục này.
   - **Quy tắc dọn dẹp**: Sau khi chạy test và debug xong, AI phải tự động dọn dẹp. Nếu script kiểm tra có giá trị tham khảo hoặc tái sử dụng cho việc gỡ lỗi về sau, hãy di chuyển chúng vào thư mục `debug_scripts/` đã được tạo sẵn. Ngược lại, nếu chỉ là rác tạm thời, hãy xóa chúng đi để dự án luôn sạch sẽ.
5. Quy định Cấu trúc Thư mục và Assets:
   - **`templates/` và `static/`**: Chỉ chứa HTML, CSS, JS cho giao diện điều khiển (Web UI Flask gốc).
   - **`assets/`**: Chứa các tài nguyên dùng để tạo code và deploy lên hệ thống đích. Nó tách biệt hoàn toàn với giao diện của hệ thống để không bị nhầm lẫn. Cụ thể gồm:
     - `assets/ai_prompts/`: Chứa `structure-template.html` và `table-template.html` dùng làm khung HTML "mồi" để nạp cho Gemini AI đọc. (Lưu ý: Không dùng tên `ai_templates` để tránh nhầm lẫn chữ `templates` của Flask).
     - `assets/img/`: Chứa các hình ảnh tĩnh chuẩn dùng để deploy thẳng lên hệ thống đích (vd: `img-ready.png`).
     - `assets/layout/`: Chứa các layout tĩnh chuẩn của trang đích (sub-template, sub-template-tab).
   - **`data/`**: Chứa CSDL JSON (sites, config, cache) và file này luôn được ẩn trong gitignore.
   - **`deployer/`**: Chứa các module chuyên biệt (site, menu, folder, upload, page) đã được chia nhỏ từ script `deploy.py` để xử lý việc tự động hóa lên CMS.
6. Quy tắc Quản lý Mã nguồn (Git & AI Agents):
   - Tuyệt đối **KHÔNG** tự động thực hiện thao tác `git push`. Mọi hành động đẩy code lên kho lưu trữ phải do người dùng tự tay thực hiện hoặc xác nhận rõ ràng.
   - Tuyệt đối **KHÔNG** được commit và push thư mục `.agents/` lên Git repository để tránh rác source code.
   - Mỗi khi thực hiện `git push` mã nguồn mới thành công (bởi người dùng), AI phải chủ động rà soát lại toàn bộ hệ thống xem có thay đổi nào về luồng logic, giao diện hay kiến trúc không. Nếu có, phải tự động đề xuất cập nhật lại các tệp trong `.agents/` (AGENTS.md, Rules, Skills) để đảm bảo "bộ não" của AI luôn được học hỏi và đồng bộ với phiên bản mới nhất của dự án.

**Đánh đổi:** Những hướng dẫn này thiên về sự cẩn trọng hơn là tốc độ. Đối với các tác vụ đơn giản, hãy sử dụng phán đoán của bạn.

## 1. Suy nghĩ trước khi code

**Đừng tự giả định. Đừng che giấu sự bối rối. Trình bày rõ các điểm đánh đổi.**

Trước khi triển khai:
- Trình bày rõ ràng các giả định của bạn. Nếu không chắc chắn, hãy hỏi.
- Nếu có nhiều cách hiểu, hãy trình bày chúng — đừng âm thầm chọn một cách.
- Nếu có cách tiếp cận đơn giản hơn, hãy nói ra. Đưa ra phản biện khi cần thiết.
- Nếu điều gì đó không rõ ràng, hãy dừng lại. Chỉ ra điểm gây bối rối. Hỏi.

## 2. Đơn giản là trên hết

**Đoạn code tối thiểu giải quyết được vấn đề. Không suy đoán.**

- Không thêm tính năng ngoài những gì được yêu cầu.
- Không tạo abstraction (trừu tượng hóa) cho code chỉ dùng một lần.
- Không thêm sự "linh hoạt" hay "có thể cấu hình" nếu không được yêu cầu.
- Không xử lý lỗi cho các kịch bản không thể xảy ra.
- Nếu bạn viết 200 dòng nhưng có thể viết trong 50 dòng, hãy viết lại.

Hãy tự hỏi: "Một kỹ sư senior có cho rằng điều này là quá phức tạp không?" Nếu có, hãy làm cho nó đơn giản hơn.

## 3. Thay đổi mang tính phẫu thuật

**Chỉ chạm vào những gì bắt buộc. Chỉ dọn dẹp mớ hỗn độn của riêng bạn.**

Khi chỉnh sửa code hiện có:
- Đừng "cải thiện" code lân cận, comment hoặc cách định dạng.
- Đừng refactor (tái cấu trúc) những thứ không bị hỏng.
- Phù hợp với style hiện tại, ngay cả khi bạn muốn làm khác đi.
- Nếu bạn nhận thấy dead code (code thừa) không liên quan, hãy đề cập đến nó — đừng xóa nó.

Khi các thay đổi của bạn tạo ra các phần mồ côi:
- Xóa các import/biến/hàm mà CÁC thay đổi CỦA BẠN làm cho chúng không còn được sử dụng.
- Đừng xóa dead code có từ trước trừ khi được yêu cầu.

Bài kiểm tra: mọi dòng bị thay đổi phải truy xuất trực tiếp được từ yêu cầu của người dùng.

## 4. Thực thi hướng tới mục tiêu

**Xác định tiêu chí thành công. Lặp lại cho đến khi được xác minh.**

Chuyển đổi các tác vụ thành các mục tiêu có thể xác minh được:
- "Thêm xác thực" → "Viết test cho các đầu vào không hợp lệ, sau đó pass chúng"
- "Sửa lỗi" → "Viết một test để tái tạo lỗi, sau đó pass nó"
- "Refactor X" → "Đảm bảo các test pass trước và sau khi refactor"

Đối với các tác vụ có nhiều bước, hãy nêu ra một kế hoạch ngắn gọn:
```
1. [Step] → verify: [check]
2. [Step] → verify: [check]
```
